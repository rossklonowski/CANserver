//
//  lcd.h
//
//
//  Created by Ross Klonowski on July 4 2020.
//

#ifndef lcd_h
#define lcd_h

void setupLCD();

void displayLoadingAnimationLCD();

#endif /* lcd_h */