//
//  bargraph.h
//
//
//  Created by Ross Klonowski on July 4 2020.
//

#ifndef bargraph_h
#define bargraph_h

void setupBargraph();

void displayLoadingAnimationBarGraph();

#endif /* bargraph_h */