//
//  button.h
//
//
//  Created by Ross Klonowski on July 4 2020.
//

#ifndef button_h
#define button_h

// #include "Arduino.h"

void checkButton();

#endif /* generalCANSignalAnalysis_h */