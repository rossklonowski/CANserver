//
//  button.cpp
//  To be used with CANserver created by Josh Wardell
//
//  Created by Ross Klonowski on July 4 2020.
//

#include <esp_now.h>
#include <Adafruit_GFX.h>
#include "Adafruit_LEDBackpack.h"
#include <stdio.h>
#include <stdlib.h>

#include "bargraph.h"

Adafruit_24bargraph bar1 = Adafruit_24bargraph();
Adafruit_24bargraph bar2 = Adafruit_24bargraph();

void setupBargraph() {
    bar1.begin(0x77);
    bar1.blinkRate(0);
    bar1.setBrightness(15);
    
    bar2.begin(0x76);
    bar2.blinkRate(0);
    bar2.setBrightness(15);
}

void displayLoadingAnimationBarGraph() {

    for (int i = 0; i < 24; i++) {
        bar1.setBar(i, LED_RED);
        bar2.setBar(i, LED_RED);
        bar1.writeDisplay();
        bar2.writeDisplay();
        delay(100);
    }

    bar1.clear();
    bar2.clear();

    for (int i = 23; i >= 0; i--) {
        bar1.setBar(i, LED_RED);
        bar2.setBar(i, LED_RED);
        bar1.writeDisplay();
        bar2.writeDisplay();
        delay(100);
    }

    bar1.clear();

    
    int pause = 50;

    bar1.setBar(0, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(23, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(1, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(22, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(2, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(21, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(3, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(20, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(4, LED_RED);    
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(19, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(5, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(18, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(6, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(17, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(7, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(16, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(8, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(15, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(9, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(14, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(10, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(13, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(11, LED_RED);
    bar1.writeDisplay();
    delay(pause);
    bar1.setBar(12, LED_RED);
    bar1.writeDisplay();
    delay(pause);    
}