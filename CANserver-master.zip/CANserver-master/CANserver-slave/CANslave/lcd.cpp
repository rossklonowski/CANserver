//
//  button.cpp
//  To be used with CANserver created by Josh Wardell
//
//  Created by Ross Klonowski on July 4 2020.
//

#include <stdio.h>
#include <stdlib.h>
#include <esp_now.h>
#include <WiFi.h>
#include <Adafruit_GFX.h>
#include "Adafruit_LEDBackpack.h"
#include <LiquidCrystal.h>

#include "lcd.h"


// Creates an LCD object. Parameters: (rs, enable, d4, d5, d6, d7)
LiquidCrystal lcd(19, 18, 5, 17, 16, 4);

void setupLCD() {
    // set up the LCD's number of columns and rows:
	lcd.begin(16, 2);
}

void displayLoadingAnimationLCD() {

    // LCD Display Loading
	lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Starting...");
    delay(2000);
    lcd.clear();
    lcd.print("Starting..");
    delay(15);
    lcd.clear();
    lcd.print("Starting.");
    delay(15);
    lcd.clear();
    lcd.print("Starting");
    delay(15);
    lcd.clear();
    lcd.print("Startin");
    delay(15);
    lcd.clear();
    lcd.print("Starti");
    delay(15);
    lcd.clear();
    lcd.print("Start");
    delay(15);
    lcd.clear();
    lcd.print("Star");
    delay(15);
    lcd.clear();
    lcd.print("Sta");
    delay(15);
    lcd.clear();
    lcd.print("St");
    delay(15);
    lcd.clear();
    lcd.print("S");
    delay(15);
    lcd.clear();
}
