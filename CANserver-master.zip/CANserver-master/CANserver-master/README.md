## CANserver
Arduino/PlatformIO software for CANserver board and microDisplay

A powerful little CANbus-to-WiFi board

http://www.jwardell.com/canserver

**[Please see all documentation in docs subdirectory](https://github.com/joshwardell/CANserver/tree/master/docs)**

![CANserver](docs/img/server3d.jpg)


Please see this thread for development discussion:
https://teslaownersonline.com/threads/canserver-development.16373/

