//
//  display.h
//
//
//  Created by Ross Klonowski on July 4 2020.
//

#ifndef display_h
#define display_h

// #include "Arduino.h"

//void checkButton();

void setupDisplays();

#endif /* display_h */
