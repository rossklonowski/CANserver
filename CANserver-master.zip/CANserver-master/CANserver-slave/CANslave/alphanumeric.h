//
//  alphanumeric.h
//
//
//  Created by Ross Klonowski on July 4 2020.
//

#ifndef alphanumeric_h
#define alphanumeric_h

void setupAlphaNum();

void displayLoadingAnimationAlpha();

void clearDisplays();

void writeDisplays();

void initDisplayUnits();

void printValueWithSingleUnit(int val, int display);

void printValueWithSingleUnit(double val, int display);

void printValueWithDoubleUnit(int val, int display) ;

void printValueWithNoUnits(int val, int display);

void printValueWithNoUnits(double val, int display);

#endif /* alphanumeric_h */
